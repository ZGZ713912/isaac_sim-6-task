#!/usr/bin/env python3
"""Zero-PPO native checks of fresh full-task reset, sequence and reward wiring.

The recovery-phase positive control starts physically upright and explicitly
marks the logical recovery phase. It tests the real native stable-hold event,
not fallen self-righting. Short diagnostic cases are never behavior scores.
"""
from copy import deepcopy
from datetime import datetime, timezone
import argparse
import json
import os
from pathlib import Path
from types import SimpleNamespace
import traceback

import train_fresh_unified as entry
from train_scratch_standing import digest, write_json
from seal_scratch_standing import original_process_live

ROOT = Path(__file__).resolve().parents[1]


def require_closed_inputs(seal_file, queue_file):
    seal, queue = [json.loads(path.read_text()) for path in (seal_file, queue_file)]
    owner=queue.get('training_identity',{})
    if (seal.get('all_checks_pass') is not True or original_process_live(seal)
            or queue.get('status') not in ('completed_unqualified','stopped') or queue.get('active_child') is not None
            or original_process_live(queue)
            or (owner.get('pid'),owner.get('start_ticks')) != (seal['pid'],seal['start_ticks'])):
        raise ValueError('Wait for the exact prior learner seal and inactive complete/stopped queue exit')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--bank', type=Path, required=True)
    parser.add_argument('--previous-seal', type=Path, required=True)
    parser.add_argument('--queue-receipt', type=Path, required=True)
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--seed', type=int, default=271101)
    args = parser.parse_args()
    require_closed_inputs(args.previous_seal, args.queue_receipt)
    entry.require_adopted_native_sources()
    args.output, args.bank = args.output.resolve(), args.bank.resolve()
    args.output.mkdir(parents=True, exist_ok=False)
    planned = SimpleNamespace(**vars(args), updates=1536, num_envs=128, rollout_steps=128,
        training_case_seed=271701, foundation_updates=192, full_tasks_at=768,
        randomization_study=ROOT/'contracts/wheel_leg_randomization_study_v2.json',
        randomization_profile='requested', randomization_strength=1.,
        domain_admission_warmup_updates=192, domain_admission_ramp_updates=128, domain_admission_seed=271501)
    cfg, task, contract = entry.prepare(planned)
    source_hashes = entry.sources()
    source_hashes['scripts/verify_fresh_unified_runtime.py'] = digest(Path(__file__))
    committed = entry.base.archive_committed_sources(source_hashes, args.output)
    receipt = dict(schema='fresh-unified-native-wiring-verification-v1', status='starting',
        pid=os.getpid(), start_ticks=int(Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19]),
        observed_utc=datetime.now(timezone.utc).isoformat(), native_policy_steps=0, physical_steps=0,
        seed=args.seed, source_commit=committed, source_sha256=source_hashes,
        bank_sha256=digest(args.bank),
        new_PPO=0, checkpoint_reads=[], qualified=False, hardware_ready=False,
        logical_recovery_fixture='Initialized upright, marked recovery; actual native stable hold must finish. This is not a fallen get-up.',
        diagnostic_cases='Lanes0/1 have short .04/.06s timeouts/sequences; lane3 starts pure standing at6deg to test real failure termination. All physical writes occur at reset.')
    write_json(args.output/'receipt.json', receipt)
    launcher = env = runner = None
    original_load = None
    try:
        from isaaclab.app import AppLauncher
        launcher = AppLauncher(dict(headless=True, device=args.device, enable_cameras=False,
            kit_args='--/exts/omni.kit.telemetry/skipDeferredStartup=true'))
        import torch
        from rsl_rl.runners import OnPolicyRunner
        from unified_training_runtime_candidate import make_environment_class
        from wheeled_tasks.chassis.control_contract import load_chassis_control
        from wheeled_tasks.chassis.physical_standing_reward import install as physical
        from wheeled_tasks.chassis.precise_standing_reward import install as precision, scores
        from wheeled_tasks.chassis.fresh_standing_failures import install as standing_failures
        from wheeled_tasks.chassis.fresh_training_objective import install as objective, attitude_density, active_speed_density, standing_velocity_density
        from wheeled_tasks.chassis.standing_support import wheel_bottom_clearance
        from wheeled_algo.scratch_standing import agent_config, initialize_fresh, tensor_hash
        from wheeled_algo.standing_load_initialization import initial_action
        from fresh_physical_metrics import install as install_extrema
        from record_scratch_physics import record

        torch.set_num_threads(4)
        torch.manual_seed(args.seed)
        entry.base.torch = torch
        original_load = torch.load

        def forbidden_load(*positional, **keywords):
            receipt['checkpoint_reads'].append(str(positional[0] if positional else keywords.get('f')))
            raise RuntimeError('No checkpoint is permitted in fresh native wiring verification')

        torch.load = forbidden_load
        manifest = json.loads((ROOT/cfg['asset_directory']/'manifest.json').read_text())
        cls = make_environment_class()
        env = cls(cfg, manifest, load_chassis_control(ROOT/cfg['control_math_source']), ROOT,
            stage_name='speed', num_envs=128, device=args.device, seed=args.seed, level=1., run_role='train',
            bank=args.bank, settings=task, training_case_seed=271701, foundation_updates=192, full_tasks_at=768)
        physical(env)
        precision(env)
        standing_failures(env)
        objective(env)
        extrema = install_extrema(env, rollout_steps=144)
        configuration = agent_config(args.seed, args.device, 128, normalize_observations=True,
            wheel_velocity_increment=True, separate_leg_velocity_feedback=True)
        configuration['actor'].update(class_name='height_initialization_candidate:HeightInitializedModel',
            height_coefficients=contract['trainable_height_initialization']['height_coefficients'])
        runner = OnPolicyRunner(env, configuration, log_dir=str(args.output), device=args.device)
        initial = initial_action(entry.base.nominal_action(env), contract['static_load_initialization'])
        receipt['initialization'] = initialize_fresh(runner.alg, initial,
            output_bias_source=contract['trainable_height_initialization']['source'])
        runner.alg.eval_mode()
        before = {name: tensor_hash(model.state_dict()) for name, model in
            (('actor', runner.alg.actor), ('critic', runner.alg.critic))}
        original_case = env.training_catalogue.case

        def diagnostic_case(lane, reset_number, clock):
            case = original_case(lane, reset_number, 0)
            if lane == 0:
                case.update(training_group='four_direction_arcs', command=[.2, 0., .305],
                    pose_index=env.height_pose[.305], duration_seconds=.04,
                    sequence=[[.02, [.2, .4, .32]], [.03, [0., 0., .305]]])
            elif lane == 1:
                case.update(training_group='stationary_spin', command=[0., .5, .305],
                    pose_index=env.height_pose[.305], duration_seconds=.06, sequence=[])
            elif lane == 3:
                case.update(training_group='standing', command=[0., 0., .305],
                    pose_index=env.height_pose[.305], pitch_deg=6.,
                    duration_seconds=30., sequence=[])
            return case

        env.training_catalogue.case = diagnostic_case
        env.reset(torch.tensor([0, 1, 3], device=env.device))
        wheels = env.robot.data.body_link_pose_w.torch[:2, env.wheel_ids]
        clearance = wheel_bottom_clearance(env.wheel_centers()[:2], wheels[:, :, 3:], env.origins[:2, 2:3])
        fixture = next(i for i, case in enumerate(env.training_reset_cases)
            if i > 3 and not env.domain.enabled[i] and case['command'][2] == .305)
        env.recovery_active[fixture] = True
        env.recovery_lane[fixture] = True
        env.released[fixture] = False
        env.ever_recovered[fixture] = False
        checks = dict(moving_and_spinning_births_grounded=bool((clearance+.00005).abs().max() < .000003),
            real_sequences=True, native_timeout_and_autoreset=True, selective_same_tick_reset=True,
            recovery_intervals_retain_native_reward=True, actual_native_completion=False,
            completion_bonus_retained=False, born_recovery_pays_standing_cost_after_completion=False,
            actual_dense_pose_cost_pre_reset=True, actual_active_speed_all5_samples=True,
            actual_dense_velocity_cost_pre_reset=True, physical_peak_witness_same_sample_and_phase=True,
            actual_objective_preserves_other_rewards_and_actions=True)
        done_counts = [0, 0]
        standing_failure_count = 0
        standing_failure_checks = True
        pose_cost_observed=False
        speed_cost_observed=False
        velocity_cost_observed=False
        completion = None
        rows = []
        for step in range(144):
            previous_phase = env.recovery_active.clone()
            peak_phase = dict(passive=env.passive.clone(), recovering=previous_phase,
                finished=env.finished.clone(), role=env.training_group.clone(),
                episode_step=env.episode_length_buf.clone())
            case = deepcopy(env.training_reset_cases[0])
            with torch.inference_mode():
                action = runner.alg.actor(env.get_observations())
                input_action=action.clone()
                _, reward, done, extras = env.step(action)
            receipt['native_policy_steps'] += 1
            receipt['physical_steps'] += env.decimation
            state = extras['diagnostics']
            if state['fresh_standing_failure'][3]:
                standing_failure_count += 1
                standing_failure_checks &= bool(done[3] and state['terminated'][3]
                    and not extras['time_outs'][3] and not extras['policy_bootstrap_mask'][3]
                    and env.episode_length_buf[3] == 0 and env.actual_episode_clock.expected[3] == 0)
            expected = state['commands'].new_tensor(case['command'])
            for at, target in case['sequence']:
                if state['time'][0] >= state['time'].new_tensor(at):
                    expected = expected.new_tensor(target)
            checks['real_sequences'] &= bool(torch.equal(state['requested_command'][0], expected))
            for lane in (0, 1):
                done_counts[lane] += int(done[lane])
            if done[:2].any():
                checks['native_timeout_and_autoreset'] &= (not bool(env.episode_length_buf[:2][done[:2]].any())
                    and bool(extras['time_outs'][:2][done[:2]].all()) and env.fixed_cases is None)
            physical_state = env.physical_standing_last
            cost = physical_state['paid_speed']+physical_state['paid_contact']+physical_state['paid_slew']
            objective_state=env.fresh_training_objective_last
            extra_cost=objective_state['paid_attitude']+objective_state['paid_velocity']+objective_state['paid_active_speed']
            expected_pose=env.policy_dt*attitude_density(state['gravity'])*objective_state['pure_standing']
            expected_speed=env.policy_dt*active_speed_density(physical_state['dq'])*objective_state['active']
            expected_velocity=env.policy_dt*standing_velocity_density(state['velocity'],state['omega'])*objective_state['pure_standing']
            checks['actual_dense_pose_cost_pre_reset'] &= bool(torch.allclose(expected_pose,objective_state['paid_attitude'],atol=1e-8,rtol=0.))
            checks['actual_active_speed_all5_samples'] &= bool(physical_state['dq'].shape==(5,128,4)
                and torch.allclose(expected_speed,objective_state['paid_active_speed'],atol=1e-8,rtol=0.))
            checks['actual_dense_velocity_cost_pre_reset'] &= bool(torch.allclose(
                expected_velocity,objective_state['paid_velocity'],atol=1e-8,rtol=0.))
            peak_index=physical_state['dq'].abs().reshape(-1).argmax()
            physical=peak_index//(128*4)
            lane=(peak_index//4)%128
            leg=peak_index%4
            speed=physical_state['dq'][physical,lane,leg]
            tau=physical_state['torque'][physical,lane,leg]
            phase=torch.where(peak_phase['finished'][lane],3,torch.where(peak_phase['passive'][lane],0,
                torch.where(peak_phase['recovering'][lane],1,2)))
            expected_peak=torch.stack((speed.abs(),speed,tau,speed*tau,lane,leg,physical+1,
                peak_index.new_tensor(step),phase,peak_phase['role'][lane],
                peak_phase['episode_step'][lane]*.005+(physical+1)*.001))
            checks['physical_peak_witness_same_sample_and_phase'] &= bool(torch.equal(
                extrema.witness.rows[step],expected_peak))
            checks['actual_objective_preserves_other_rewards_and_actions'] &= bool(torch.equal(action,input_action)
                and torch.allclose(reward,objective_state['unmodified_reward']-extra_cost,atol=3e-7,rtol=0.)
                and not objective_state['pure_standing'][fixture])
            pose_cost_observed |= bool(expected_pose[3]>0.)
            speed_cost_observed |= bool(expected_speed.max()>0.)
            velocity_cost_observed |= bool(expected_velocity.max()>0.)
            if previous_phase[fixture]:
                checks['recovery_intervals_retain_native_reward'] &= bool(torch.isclose(
                    reward[fixture], state['native_reward'][fixture]-cost[fixture]-extra_cost[fixture], atol=3e-7, rtol=0.))
            if previous_phase[fixture] and not state['reward_recovery_active'][fixture] and not done[fixture]:
                completion = float(state['time'][fixture])
                checks['actual_native_completion'] = bool(state['recovered'][fixture] and state['stable'][fixture])
                checks['completion_bonus_retained'] = bool(reward[fixture] > 2.5)
            if completion is not None and not previous_phase[fixture] and not done[fixture]:
                density = scores(state['height'], state['gravity'], state['velocity'], state['omega'], state['commands'][:, 2])
                expected_reward = density*env.policy_dt-cost-extra_cost-3.*state['terminated']
                checks['born_recovery_pays_standing_cost_after_completion'] |= bool(cost[fixture] > 0.
                    and torch.isclose(reward[fixture], expected_reward[fixture], atol=1e-7, rtol=0.))
            if step == 20:
                before_obs = env.get_observations()['policy'][1:].clone()
                history = env.domain.sensor_history[:, 1:].clone()
                cursor = env.domain.sensor_cursor
                pose = env.robot.data.root_link_pose_w.torch[1:].clone()
                joints = env.robot.data.joint_pos.torch[1:].clone()
                env.reset(torch.tensor([0], device=env.device))
                after_obs = env.get_observations()['policy'][1:]
                checks['selective_same_tick_reset'] = bool(torch.equal(before_obs, after_obs)
                    and torch.equal(history, env.domain.sensor_history[:, 1:]) and cursor == env.domain.sensor_cursor
                    and torch.equal(pose, env.robot.data.root_link_pose_w.torch[1:])
                    and torch.equal(joints, env.robot.data.joint_pos.torch[1:]))
            if step < 12 or step % 16 == 0 or completion is not None and abs(float(state['time'][fixture])-completion) < .015:
                rows.append(dict(step=step, lane0_time_s=float(state['time'][0]),
                    lane0_request=state['requested_command'][0].tolist(), lane0_done=bool(done[0]),
                    fixture_time_s=float(state['time'][fixture]), fixture_native_reward=float(state['native_reward'][fixture]),
                    fixture_final_reward=float(reward[fixture]), fixture_cost=float(cost[fixture]),
                    fixture_recovery_before=bool(previous_phase[fixture]),
                    fixture_recovery_after=bool(state['reward_recovery_active'][fixture])))
        checks['multiple_real_autoresets'] = min(done_counts) > 5
        checks['actual_dense_pose_cost_pre_reset'] &= pose_cost_observed
        checks['actual_active_speed_all5_samples'] &= speed_cost_observed
        checks['actual_dense_velocity_cost_pre_reset'] &= velocity_cost_observed
        checks['actual_case_scoped_standing_failure_no_bootstrap'] = (
            standing_failure_count > 0 and standing_failure_checks)
        checks['no_optimizer_or_parameter_updates'] = not runner.alg.optimizer.state and all(
            tensor_hash(model.state_dict()) == before[name] for name, model in
            (('actor', runner.alg.actor), ('critic', runner.alg.critic)))
        checks['all_sources_unchanged'] = all(digest(ROOT/name) == value for name, value in source_hashes.items())
        physics = record(env)
        checks['native_clock_and_solver_unchanged'] = (
            physics['physical_dt_s'] == .001 and physics['policy_dt_s'] == .005
            and physics['articulation_iterations']['physxArticulation:solverPositionIterationCount'] == 64
            and physics['articulation_iterations']['physxArticulation:solverVelocityIterationCount'] == 32)
        observed_extrema = extrema.snapshot(144)
        runner.logger.init_logging_writer()
        logged_extrema = extrema.write(runner.logger.writer, 1, 144)
        checks['physical_extrema_flush_after_inference'] = (logged_extrema == observed_extrema
            and extrema.policy_calls == 0 and not extrema.peak_per_leg.is_inference()
            and not bool(extrema.peak_per_leg.any()) and not bool(extrema.counts.any())
            and extrema.witness.calls == 0 and not extrema.witness.rows.is_inference()
            and not bool(extrema.witness.rows.any()))
        receipt.update(status='completed_unqualified', checks=checks, all_checks_pass=all(checks.values()),
            phase_fixture_lane=fixture, actual_completion_time_s=completion, lane01_autoreset_counts=done_counts,
            startup_report=env.startup_report, physics_runtime=physics, diagnostic_rows=rows,
            actual_case_scoped_standing_failure_events=standing_failure_count,
            observed_physical_extrema=observed_extrema)
        for name, value in checks.items():
            runner.logger.writer.add_scalar('NativeRuntimeCheck/'+name, float(value), 0)
        if not receipt['all_checks_pass']:
            raise ValueError('Native fresh runtime checks failed; preserve evidence and do not start PPO')
    except BaseException:
        receipt.update(status='failed', error=traceback.format_exc())
        raise
    finally:
        write_json(args.output/'receipt.json', receipt)
        if original_load is not None:
            torch.load = original_load
        if runner is not None and runner.logger.writer is not None:
            runner.logger.writer.flush()
            runner.logger.writer.close()
        if env is not None:
            env.close()
        if launcher is not None:
            launcher.app.close()
    print(json.dumps(dict(status=receipt['status'], all_checks_pass=receipt['all_checks_pass'], new_PPO=0)))


if __name__ == '__main__':
    main()
